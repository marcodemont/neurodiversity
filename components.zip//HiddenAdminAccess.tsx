import { useState, useEffect } from 'react';
import { supabase } from '../utils/supabase/client';

interface HiddenAdminAccessProps {
  onAdminAccess: (token: string) => void;
}

export function HiddenAdminAccess({ onAdminAccess }: HiddenAdminAccessProps) {
  const [keySequence, setKeySequence] = useState<string[]>([]);
  const [isListening, setIsListening] = useState(false);

  // Secret key sequence: Ctrl+Shift+A followed by "marco"
  const SECRET_SEQUENCE = ['Control', 'Shift', 'KeyA', 'KeyM', 'KeyA', 'KeyR', 'KeyC', 'KeyO'];

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      // Start sequence detection with Ctrl+Shift+A
      if (event.ctrlKey && event.shiftKey && event.code === 'KeyA') {
        setIsListening(true);
        setKeySequence(['Control', 'Shift', 'KeyA']);
        return;
      }

      if (isListening) {
        const newSequence = [...keySequence, event.code];
        setKeySequence(newSequence);

        // Check if sequence matches
        const sequenceMatches = newSequence.every((key, index) => key === SECRET_SEQUENCE[index]);
        
        if (sequenceMatches && newSequence.length === SECRET_SEQUENCE.length) {
          // Secret sequence completed - attempt auto-login
          attemptHiddenLogin();
          resetSequence();
        } else if (!sequenceMatches || newSequence.length >= SECRET_SEQUENCE.length) {
          // Wrong key or sequence too long - reset
          resetSequence();
        }
      }
    };

    const resetSequence = () => {
      setKeySequence([]);
      setIsListening(false);
    };

    // Reset sequence after 3 seconds of inactivity
    const resetTimer = setTimeout(resetSequence, 3000);

    window.addEventListener('keydown', handleKeyDown);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      clearTimeout(resetTimer);
    };
  }, [keySequence, isListening]);

  const attemptHiddenLogin = async () => {
    try {
      // Check if user is already authenticated
      const { data: session } = await supabase.auth.getSession();
      
      if (session?.session?.access_token) {
        // User is already logged in, check if they're the hidden admin
        const response = await fetch(`https://${window.location.hostname === 'localhost' ? 'localhost:54321' : window.location.hostname}.supabase.co/functions/v1/make-server-dd06a358/profile`, {
          headers: {
            'Authorization': `Bearer ${session.session.access_token}`
          }
        });
        
        if (response.ok) {
          const data = await response.json();
          if (data.profile && data.profile.role === 'super_admin' && data.profile.hidden) {
            // Hidden super admin detected - grant access
            localStorage.setItem('admin_token', session.session.access_token);
            onAdminAccess(session.session.access_token);
          }
        }
      }
    } catch (error) {
      // Silent fail - don't expose functionality
      console.log('Access check complete');
    }
  };

  // This component renders nothing visible
  return null;
}