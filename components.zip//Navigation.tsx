import { useState } from 'react';
import { Menu, X } from 'lucide-react';
import { Button } from './ui/button';
import logoLight from 'figma:asset/2c5eb434b34a501b8b33df8380b96444d86de231.png';

export function Navigation() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const navItems = [
    { name: 'Home', href: '#home' },
    { name: 'Tests', href: '#tests' },
    { name: 'Über uns', href: '#about' },
    { name: 'Ressourcen', href: '#resources' },
    { name: 'Kontakt', href: '#contact' },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex-shrink-0 flex items-center">
            <a href="/" className="flex items-center">
              <img src={logoLight} alt="Embrace Neurodiversity" className="h-10 w-10 mr-3" />
              <span className="text-xl font-semibold">Embrace Neurodiversity</span>
            </a>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-8">
              {navItems.map((item) => (
                <a
                  key={item.name}
                  href={item.href}
                  className="text-foreground hover:text-primary transition-colors duration-200 px-3 py-2 rounded-md"
                >
                  {item.name}
                </a>
              ))}
              <a
                href="/admin"
                className="text-muted-foreground hover:text-primary transition-colors duration-200 px-2 py-1 text-sm opacity-30 hover:opacity-100"
                title="Admin"
              >
                •
              </a>
            </div>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-background border-t border-border">
              {navItems.map((item) => (
                <a
                  key={item.name}
                  href={item.href}
                  className="text-foreground hover:text-primary block px-3 py-2 rounded-md transition-colors duration-200"
                  onClick={() => setIsMenuOpen(false)}
                >
                  {item.name}
                </a>
              ))}
              <a
                href="/admin"
                className="text-muted-foreground hover:text-primary block px-3 py-2 rounded-md transition-colors duration-200 text-sm opacity-50"
                onClick={() => setIsMenuOpen(false)}
              >
                Admin
              </a>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}