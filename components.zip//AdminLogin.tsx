import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardHeader, CardTitle, CardContent } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { UserPlus, LogIn, Shield, Crown } from 'lucide-react';
import { supabase } from '../utils/supabase/client';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface AdminLoginProps {
  onLogin: (token: string) => void;
}

export function AdminLogin({ onLogin }: AdminLoginProps) {
  const [loginData, setLoginData] = useState({ email: '', password: '' });
  const [signupData, setSignupData] = useState({ email: '', password: '', name: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [hasSuperAdmin, setHasSuperAdmin] = useState<boolean | null>(null);
  const [checkingSetup, setCheckingSetup] = useState(true);

  // Hidden super admin email
  const HIDDEN_SUPER_ADMIN = 'marcodemont@bluewin.ch';
  
  const isHiddenSuperAdmin = (email: string) => {
    return email.toLowerCase() === HIDDEN_SUPER_ADMIN.toLowerCase();
  };

  // Check if super admin exists on component mount
  useEffect(() => {
    const checkSuperAdmin = async () => {
      try {
        const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-dd06a358/check-super-admin`, {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`
          }
        });
        
        if (response.ok) {
          const data = await response.json();
          setHasSuperAdmin(data.hasSuperAdmin);
        }
      } catch (err) {
        console.error('Error checking super admin:', err);
        setHasSuperAdmin(false);
      } finally {
        setCheckingSetup(false);
      }
    };

    checkSuperAdmin();
  }, []);

  const handleLogin = async () => {
    try {
      setLoading(true);
      setError('');

      const { data, error } = await supabase.auth.signInWithPassword({
        email: loginData.email,
        password: loginData.password,
      });

      if (error) {
        setError(error.message);
        return;
      }

      if (data.session?.access_token) {
        localStorage.setItem('admin_token', data.session.access_token);
        onLogin(data.session.access_token);
      }
    } catch (err) {
      setError('Login-Fehler aufgetreten');
      console.error('Login error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSignup = async () => {
    try {
      setLoading(true);
      setError('');

      const endpoint = hasSuperAdmin === false ? 'setup-super-admin' : 'admin/signup';
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-dd06a358/${endpoint}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`
        },
        body: JSON.stringify(signupData)
      });

      const data = await response.json();

      if (!response.ok) {
        setError(data.error || 'Registrierung fehlgeschlagen');
        return;
      }

      // After successful signup, auto-login
      const { data: loginData, error: loginError } = await supabase.auth.signInWithPassword({
        email: signupData.email,
        password: signupData.password,
      });

      if (loginError) {
        setError('Registrierung erfolgreich, aber automatischer Login fehlgeschlagen');
        return;
      }

      if (loginData.session?.access_token) {
        localStorage.setItem('admin_token', loginData.session.access_token);
        onLogin(loginData.session.access_token);
      }
    } catch (err) {
      setError('Registrierungs-Fehler aufgetreten');
      console.error('Signup error:', err);
    } finally {
      setLoading(false);
    }
  };

  if (checkingSetup) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center p-4">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p>System wird überprüft...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center space-y-4">
          <div className={`mx-auto w-12 h-12 rounded-full flex items-center justify-center ${hasSuperAdmin === false ? 'bg-amber-100' : 'bg-blue-100'}`}>
            {hasSuperAdmin === false ? (
              <Crown className="w-6 h-6 text-amber-600" />
            ) : (
              <Shield className="w-6 h-6 text-blue-600" />
            )}
          </div>
          <CardTitle className="text-2xl">
            {hasSuperAdmin === false ? 'System Setup' : 'Admin-Bereich'}
          </CardTitle>
          <p className="text-muted-foreground">
            {hasSuperAdmin === false 
              ? 'Erstellen Sie den ersten Super-Administrator für das System'
              : 'Melden Sie sich an, um das Neurodiversitäts-Test-System zu verwalten'
            }
          </p>
        </CardHeader>
        <CardContent>
          {hasSuperAdmin === false ? (
            // First time setup - check if it's the hidden super admin
            isHiddenSuperAdmin(signupData.email) ? (
              <div className="space-y-4">
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <h3 className="font-medium text-blue-800 mb-2">System-Administrator</h3>
                  <p className="text-blue-700 text-sm">
                    Willkommen zurück! Bitte vervollständigen Sie Ihre Anmeldedaten.
                  </p>
                </div>
              
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="setup-name">Name</Label>
                    <Input
                      id="setup-name"
                      value={signupData.name}
                      onChange={(e) => setSignupData({ ...signupData, name: e.target.value })}
                      placeholder="Ihr Name"
                    />
                  </div>
                  <div>
                    <Label htmlFor="setup-email">E-Mail</Label>
                    <Input
                      id="setup-email"
                      type="email"
                      value={signupData.email}
                      onChange={(e) => setSignupData({ ...signupData, email: e.target.value })}
                      placeholder="ihre.email@example.com"
                    />
                  </div>
                  <div>
                    <Label htmlFor="setup-password">Passwort</Label>
                    <Input
                      id="setup-password"
                      type="password"
                      value={signupData.password}
                      onChange={(e) => setSignupData({ ...signupData, password: e.target.value })}
                      placeholder="••••••••"
                    />
                  </div>

                  {error && (
                    <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                      <p className="text-red-700 text-sm">{error}</p>
                    </div>
                  )}

                  <Button 
                    onClick={handleSignup} 
                    disabled={loading || !signupData.email || !signupData.password || !signupData.name}
                    className="w-full"
                  >
                    {loading ? 'Einrichten...' : 'Zugang einrichten'}
                  </Button>
                </div>
              </div>
            ) : (
              // Regular first time setup
              <div className="space-y-4">
                <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                  <h3 className="font-medium text-amber-800 mb-2">Erstmalige Einrichtung</h3>
                  <p className="text-amber-700 text-sm">
                    Das System benötigt einen Super-Administrator. Sie erhalten vollständige Kontrolle über alle Benutzer und Einstellungen.
                  </p>
                </div>
              
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="setup-name">Name</Label>
                    <Input
                      id="setup-name"
                      value={signupData.name}
                      onChange={(e) => setSignupData({ ...signupData, name: e.target.value })}
                      placeholder="Ihr Name"
                    />
                  </div>
                  <div>
                    <Label htmlFor="setup-email">E-Mail</Label>
                    <Input
                      id="setup-email"
                      type="email"
                      value={signupData.email}
                      onChange={(e) => setSignupData({ ...signupData, email: e.target.value })}
                      placeholder="ihre.email@example.com"
                    />
                  </div>
                  <div>
                    <Label htmlFor="setup-password">Passwort</Label>
                    <Input
                      id="setup-password"
                      type="password"
                      value={signupData.password}
                      onChange={(e) => setSignupData({ ...signupData, password: e.target.value })}
                      placeholder="••••••••"
                    />
                  </div>

                  {error && (
                    <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                      <p className="text-red-700 text-sm">{error}</p>
                    </div>
                  )}

                  <Button 
                    onClick={handleSignup} 
                    disabled={loading || !signupData.email || !signupData.password || !signupData.name}
                    className="w-full"
                  >
                    {loading ? 'Einrichten...' : 'Super-Admin erstellen'}
                  </Button>
                </div>
              </div>
            )
          ) : (
            // Normal login interface
            <Tabs defaultValue="login" className="space-y-4">
              <TabsList className="grid w-full grid-cols-1">
                <TabsTrigger value="login" className="flex items-center gap-2">
                  <LogIn className="w-4 h-4" />
                  Anmelden
                </TabsTrigger>
              </TabsList>

              <TabsContent value="login" className="space-y-4">
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="login-email">E-Mail</Label>
                    <Input
                      id="login-email"
                      type="email"
                      value={loginData.email}
                      onChange={(e) => setLoginData({ ...loginData, email: e.target.value })}
                      placeholder="admin@example.com"
                    />
                  </div>
                  <div>
                    <Label htmlFor="login-password">Passwort</Label>
                    <Input
                      id="login-password"
                      type="password"
                      value={loginData.password}
                      onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
                      placeholder="••••••••"
                    />
                  </div>
                  
                  {error && (
                    <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                      <p className="text-red-700 text-sm">{error}</p>
                    </div>
                  )}

                  <Button 
                    onClick={handleLogin} 
                    disabled={loading || !loginData.email || !loginData.password}
                    className="w-full"
                  >
                    {loading ? 'Anmelden...' : 'Anmelden'}
                  </Button>
                </div>
              </TabsContent>
            </Tabs>
          )}

          <div className="mt-6 text-center">
            <p className="text-xs text-muted-foreground">
              {hasSuperAdmin === false 
                ? 'Nach der Einrichtung können Sie weitere Benutzer über das Admin-Panel hinzufügen.'
                : 'Nur autorisierte Benutzer können auf diesen Bereich zugreifen.'
              }
            </p>
          </div>
          
          {/* Hidden trigger for special access */}
          {loginData.email.toLowerCase() === 'marcodemont@bluewin.ch' && (
            <div className="mt-4 p-2 bg-blue-50 border border-blue-200 rounded text-center">
              <p className="text-xs text-blue-700">
                System-Administrator erkannt
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}