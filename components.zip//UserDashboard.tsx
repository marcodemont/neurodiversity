import { useState, useEffect } from 'react';
import { Button } from '../components/ui/button';
import { Card, CardHeader, CardTitle, CardContent } from '../components/ui/card';
import { Progress } from '../components/ui/progress';
import { Badge } from '../components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { 
  Brain, 
  Users, 
  Eye, 
  Zap, 
  Heart, 
  BarChart3, 
  BookOpen, 
  Settings, 
  LogOut,
  Play,
  CheckCircle,
  Clock,
  TrendingUp
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from 'recharts';

interface UserDashboardProps {
  user: any;
  onLogout: () => void;
  onStartTest: (testType: string) => void;
}

const availableTests = [
  {
    id: 'raads-r',
    name: 'RAADS-R',
    fullName: 'Ritvo Autism Asperger Diagnostic Scale - Revised',
    description: 'Umfassendes Autismus-Screening für Erwachsene',
    category: 'autism',
    questions: 80,
    duration: '15-20 Min',
    icon: Brain,
    color: 'from-blue-500 to-purple-500'
  },
  {
    id: 'cat-q',
    name: 'CAT-Q',
    fullName: 'Camouflaging Autistic Traits Questionnaire',
    description: 'Erfassung von Masking-Verhalten und Kompensationsstrategien',
    category: 'masking',
    questions: 25,
    duration: '8-10 Min',
    icon: Eye,
    color: 'from-purple-500 to-pink-500'
  },
  {
    id: 'asrs',
    name: 'ASRS',
    fullName: 'Adult ADHD Self-Report Scale',
    description: 'ADHS-Screening für Erwachsene',
    category: 'adhd',
    questions: 18,
    duration: '5-8 Min',
    icon: Zap,
    color: 'from-orange-500 to-red-500'
  },
  {
    id: 'aq',
    name: 'AQ',
    fullName: 'Autism Quotient',
    description: 'Kurzes Autismus-Spektrum-Screening',
    category: 'autism',
    questions: 50,
    duration: '10-12 Min',
    icon: Users,
    color: 'from-green-500 to-teal-500'
  },
  {
    id: 'eq',
    name: 'EQ',
    fullName: 'Empathy Quotient',
    description: 'Messung der Empathiefähigkeit',
    category: 'empathy',
    questions: 60,
    duration: '12-15 Min',
    icon: Heart,
    color: 'from-pink-500 to-rose-500'
  }
];

export function UserDashboard({ user, onLogout, onStartTest }: UserDashboardProps) {
  const [completedTests, setCompletedTests] = useState([]);
  const [currentResults, setCurrentResults] = useState([]);
  
  // Mock data - in real app this would come from backend
  useEffect(() => {
    // Mock completed tests
    setCompletedTests(['raads-r', 'cat-q']);
    
    // Mock results data
    setCurrentResults([
      { category: 'Soziale Kommunikation', score: 75, maxScore: 100, color: '#3b82f6' },
      { category: 'Masking & Kompensation', score: 68, maxScore: 100, color: '#8b5cf6' },
      { category: 'Routinen / Sensorik', score: 82, maxScore: 100, color: '#f59e0b' },
      { category: 'Aufmerksamkeitsregulation', score: 45, maxScore: 100, color: '#10b981' },
      { category: 'Emotionale Steuerung', score: 71, maxScore: 100, color: '#ef4444' }
    ]);
  }, []);

  const radarData = currentResults.map(result => ({
    category: result.category.split(' ')[0], // Shorten for radar
    score: result.score,
    fullName: result.category
  }));

  const getTestStatus = (testId: string) => {
    if (completedTests.includes(testId)) {
      return { status: 'completed', label: 'Abgeschlossen', color: 'bg-green-500' };
    }
    return { status: 'available', label: 'Verfügbar', color: 'bg-blue-500' };
  };

  const overallScore = currentResults.length > 0 
    ? Math.round(currentResults.reduce((acc, result) => acc + result.score, 0) / currentResults.length)
    : 0;

  return (
    <div className="min-h-screen pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold">Willkommen, {user.name}!</h1>
            <p className="text-gray-600 mt-1">Ihr persönliches Neurodiversitäts-Dashboard</p>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="outline" size="sm">
              <Settings className="w-4 h-4 mr-2" />
              Einstellungen
            </Button>
            <Button variant="outline" size="sm" onClick={onLogout}>
              <LogOut className="w-4 h-4 mr-2" />
              Abmelden
            </Button>
          </div>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 max-w-2xl">
            <TabsTrigger value="overview">Übersicht</TabsTrigger>
            <TabsTrigger value="tests">Tests</TabsTrigger>
            <TabsTrigger value="results">Ergebnisse</TabsTrigger>
            <TabsTrigger value="insights">Erkenntnisse</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Progress Overview */}
            <div className="grid md:grid-cols-3 gap-6">
              <Card className="bg-gradient-to-br from-blue-50 to-purple-50 border-blue-200">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">Abgeschlossene Tests</p>
                      <p className="text-3xl font-bold text-blue-600">
                        {completedTests.length}/{availableTests.length}
                      </p>
                    </div>
                    <CheckCircle className="w-10 h-10 text-blue-600" />
                  </div>
                  <Progress 
                    value={(completedTests.length / availableTests.length) * 100} 
                    className="mt-4" 
                  />
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-green-50 to-teal-50 border-green-200">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">Gesamtscore</p>
                      <p className="text-3xl font-bold text-green-600">{overallScore}%</p>
                    </div>
                    <TrendingUp className="w-10 h-10 text-green-600" />
                  </div>
                  <p className="text-sm text-gray-600 mt-2">
                    Basierend auf {completedTests.length} Tests
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-orange-50 to-red-50 border-orange-200">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">Nächster Test</p>
                      <p className="text-lg font-semibold text-orange-600">
                        {availableTests.find(test => !completedTests.includes(test.id))?.name || 'Alle abgeschlossen'}
                      </p>
                    </div>
                    <Clock className="w-10 h-10 text-orange-600" />
                  </div>
                  <p className="text-sm text-gray-600 mt-2">
                    Empfohlener nächster Schritt
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Schnellaktionen</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4">
                  <Button 
                    onClick={() => {
                      const nextTest = availableTests.find(test => !completedTests.includes(test.id));
                      if (nextTest) onStartTest(nextTest.id);
                    }}
                    className="bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600 h-12"
                  >
                    <Play className="w-5 h-5 mr-2" />
                    Nächsten Test starten
                  </Button>
                  <Button variant="outline" className="h-12">
                    <BookOpen className="w-5 h-5 mr-2" />
                    Ergebnisse interpretieren
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="tests" className="space-y-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {availableTests.map((test) => {
                const status = getTestStatus(test.id);
                const IconComponent = test.icon;
                
                return (
                  <Card key={test.id} className="hover:shadow-lg transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div className={`p-3 rounded-lg bg-gradient-to-r ${test.color}`}>
                          <IconComponent className="w-6 h-6 text-white" />
                        </div>
                        <Badge 
                          className={`${status.color} text-white`}
                        >
                          {status.label}
                        </Badge>
                      </div>
                      
                      <h3 className="text-lg font-semibold mb-1">{test.name}</h3>
                      <p className="text-sm text-gray-600 mb-3">{test.description}</p>
                      
                      <div className="flex justify-between text-sm text-gray-500 mb-4">
                        <span>{test.questions} Fragen</span>
                        <span>{test.duration}</span>
                      </div>
                      
                      <Button 
                        onClick={() => onStartTest(test.id)}
                        className="w-full"
                        variant={status.status === 'completed' ? 'outline' : 'default'}
                      >
                        {status.status === 'completed' ? 'Wiederholen' : 'Starten'}
                      </Button>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="results" className="space-y-6">
            {currentResults.length > 0 ? (
              <>
                <div className="grid lg:grid-cols-2 gap-6">
                  {/* Bar Chart */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Kategorien-Übersicht</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ResponsiveContainer width="100%" height={300}>
                        <BarChart data={currentResults}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis 
                            dataKey="category" 
                            angle={-45} 
                            textAnchor="end" 
                            height={80}
                            fontSize={12}
                          />
                          <YAxis />
                          <Tooltip />
                          <Bar dataKey="score" fill="#3b82f6" />
                        </BarChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>

                  {/* Radar Chart */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Profil-Radar</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ResponsiveContainer width="100%" height={300}>
                        <RadarChart data={radarData}>
                          <PolarGrid />
                          <PolarAngleAxis dataKey="category" />
                          <PolarRadiusAxis angle={90} domain={[0, 100]} />
                          <Radar
                            name="Score"
                            dataKey="score"
                            stroke="#3b82f6"
                            fill="#3b82f6"
                            fillOpacity={0.3}
                          />
                          <Tooltip />
                        </RadarChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>
                </div>

                {/* Detailed Results */}
                <Card>
                  <CardHeader>
                    <CardTitle>Detaillierte Auswertung</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {currentResults.map((result, index) => (
                        <div key={index} className="p-4 border rounded-lg">
                          <div className="flex items-center justify-between mb-2">
                            <h4 className="font-semibold" style={{ color: result.color }}>
                              {result.category}
                            </h4>
                            <span className="font-bold text-lg">{result.score}%</span>
                          </div>
                          <Progress value={result.score} className="mb-2" />
                          <p className="text-sm text-gray-600">
                            Score von {result.score} von {result.maxScore} möglichen Punkten
                          </p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </>
            ) : (
              <Card>
                <CardContent className="text-center py-12">
                  <BarChart3 className="w-16 h-16 mx-auto text-gray-400 mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Noch keine Ergebnisse</h3>
                  <p className="text-gray-600 mb-4">
                    Starten Sie Ihren ersten Test, um Ihre Ergebnisse hier zu sehen.
                  </p>
                  <Button onClick={() => onStartTest('raads-r')}>
                    Ersten Test starten
                  </Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="insights" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Persönliche Erkenntnisse</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <h4 className="font-semibold text-blue-800 mb-2">Stärken-Profil</h4>
                    <p className="text-blue-700 text-sm">
                      Ihre Ergebnisse zeigen besondere Stärken in der Detailwahrnehmung 
                      und systematischen Herangehensweise. Dies sind wertvolle Eigenschaften 
                      in vielen Bereichen.
                    </p>
                  </div>

                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <h4 className="font-semibold text-green-800 mb-2">Empfehlungen</h4>
                    <ul className="text-green-700 text-sm space-y-1">
                      <li>• Nutzen Sie Ihre systematischen Fähigkeiten gezielt</li>
                      <li>• Schaffen Sie strukturierte Arbeitsumgebungen</li>
                      <li>• Entwickeln Sie Strategien für soziale Situationen</li>
                    </ul>
                  </div>

                  <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                    <h4 className="font-semibold text-amber-800 mb-2">Nächste Schritte</h4>
                    <p className="text-amber-700 text-sm">
                      Für eine professionelle Einschätzung empfehlen wir ein Gespräch 
                      mit spezialisierten Fachkräften. Diese Ergebnisse können als 
                      Gesprächsgrundlage dienen.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}