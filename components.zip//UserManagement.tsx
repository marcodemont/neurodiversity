import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardHeader, CardTitle, CardContent } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from './ui/alert-dialog';
import { Badge } from './ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Plus, Edit, Trash2, Crown, Shield, User, Eye } from 'lucide-react';
import { projectId } from '../utils/supabase/info';

interface UserProfile {
  userId: string;
  email: string;
  name: string;
  role: string;
  createdAt: string;
  createdBy?: string;
}

const USER_ROLES = {
  SUPER_ADMIN: 'super_admin',
  ADMIN: 'admin', 
  USER: 'user',
  VIEWER: 'viewer'
};

const roleInfo = {
  [USER_ROLES.SUPER_ADMIN]: { 
    name: 'Super Admin', 
    icon: Crown, 
    color: 'bg-amber-100 text-amber-800 border-amber-200',
    description: 'Vollständige Kontrolle über das System'
  },
  [USER_ROLES.ADMIN]: { 
    name: 'Administrator', 
    icon: Shield, 
    color: 'bg-blue-100 text-blue-800 border-blue-200',
    description: 'Kann Fragen verwalten und Tests administrieren'
  },
  [USER_ROLES.USER]: { 
    name: 'Benutzer', 
    icon: User, 
    color: 'bg-green-100 text-green-800 border-green-200',
    description: 'Kann Tests durchführen und eigene Ergebnisse einsehen'
  },
  [USER_ROLES.VIEWER]: { 
    name: 'Betrachter', 
    icon: Eye, 
    color: 'bg-gray-100 text-gray-800 border-gray-200',
    description: 'Kann nur Testergebnisse einsehen'
  }
};

interface UserManagementProps {
  userProfile: UserProfile;
}

export function UserManagement({ userProfile }: UserManagementProps) {
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [newUser, setNewUser] = useState({ name: '', email: '', password: '', role: USER_ROLES.USER });
  const [editingUser, setEditingUser] = useState<UserProfile | null>(null);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);

  const getAuthToken = () => localStorage.getItem('admin_token');

  const apiCall = async (endpoint: string, options: RequestInit = {}) => {
    const token = getAuthToken();
    const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-dd06a358${endpoint}`, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
        ...options.headers
      }
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error || `API call failed: ${response.statusText}`);
    }

    return response.json();
  };

  const loadUsers = async () => {
    try {
      setLoading(true);
      const data = await apiCall('/admin/users');
      setUsers(data.users || []);
    } catch (error) {
      console.error('Error loading users:', error);
    } finally {
      setLoading(false);
    }
  };

  const addUser = async () => {
    try {
      const data = await apiCall('/admin/users', {
        method: 'POST',
        body: JSON.stringify(newUser)
      });
      
      if (data) {
        await loadUsers();
        setNewUser({ name: '', email: '', password: '', role: USER_ROLES.USER });
        setIsAddDialogOpen(false);
      }
    } catch (error) {
      console.error('Error adding user:', error);
      alert(`Fehler beim Hinzufügen des Benutzers: ${error.message}`);
    }
  };

  const updateUser = async () => {
    if (!editingUser) return;
    
    try {
      const data = await apiCall(`/admin/users/${editingUser.userId}`, {
        method: 'PUT',
        body: JSON.stringify({
          name: editingUser.name,
          role: editingUser.role
        })
      });
      
      if (data) {
        await loadUsers();
        setEditingUser(null);
        setIsEditDialogOpen(false);
      }
    } catch (error) {
      console.error('Error updating user:', error);
      alert(`Fehler beim Aktualisieren des Benutzers: ${error.message}`);
    }
  };

  const deleteUser = async (userId: string) => {
    try {
      const data = await apiCall(`/admin/users/${userId}`, {
        method: 'DELETE'
      });
      
      if (data) {
        await loadUsers();
      }
    } catch (error) {
      console.error('Error deleting user:', error);
      alert(`Fehler beim Löschen des Benutzers: ${error.message}`);
    }
  };

  useEffect(() => {
    if (userProfile.role === USER_ROLES.SUPER_ADMIN) {
      loadUsers();
    }
  }, [userProfile]);

  if (userProfile.role !== USER_ROLES.SUPER_ADMIN) {
    return (
      <Card>
        <CardContent className="text-center py-12">
          <Shield className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground">
            Nur Super-Administratoren können Benutzer verwalten.
          </p>
        </CardContent>
      </Card>
    );
  }

  if (loading) {
    return (
      <Card>
        <CardContent className="text-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p>Lade Benutzer...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl">Benutzerverwaltung</h2>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="flex items-center gap-2">
              <Plus className="w-4 h-4" />
              Neuen Benutzer hinzufügen
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Neuen Benutzer hinzufügen</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="name">Name</Label>
                <Input
                  id="name"
                  value={newUser.name}
                  onChange={(e) => setNewUser({...newUser, name: e.target.value})}
                  placeholder="Vollständiger Name"
                />
              </div>
              <div>
                <Label htmlFor="email">E-Mail</Label>
                <Input
                  id="email"
                  type="email"
                  value={newUser.email}
                  onChange={(e) => setNewUser({...newUser, email: e.target.value})}
                  placeholder="benutzer@example.com"
                />
              </div>
              <div>
                <Label htmlFor="password">Passwort</Label>
                <Input
                  id="password"
                  type="password"
                  value={newUser.password}
                  onChange={(e) => setNewUser({...newUser, password: e.target.value})}
                  placeholder="Temporäres Passwort"
                />
              </div>
              <div>
                <Label htmlFor="role">Rolle</Label>
                <Select value={newUser.role} onValueChange={(value) => setNewUser({...newUser, role: value})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(roleInfo).filter(([key]) => key !== USER_ROLES.SUPER_ADMIN).map(([key, info]) => (
                      <SelectItem key={key} value={key}>
                        <div className="flex items-center gap-2">
                          <info.icon className="w-4 h-4" />
                          {info.name}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <p className="text-sm text-muted-foreground mt-1">
                  {roleInfo[newUser.role as keyof typeof roleInfo]?.description}
                </p>
              </div>
              <div className="flex justify-end gap-2 pt-4">
                <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  Abbrechen
                </Button>
                <Button 
                  onClick={addUser} 
                  disabled={!newUser.name.trim() || !newUser.email.trim() || !newUser.password.trim()}
                >
                  Benutzer erstellen
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Alle Benutzer ({users.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>E-Mail</TableHead>
                  <TableHead>Rolle</TableHead>
                  <TableHead>Erstellt am</TableHead>
                  <TableHead className="text-right">Aktionen</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {users.map((user) => {
                  const RoleIcon = roleInfo[user.role as keyof typeof roleInfo]?.icon || User;
                  const isCurrentUser = user.userId === userProfile.userId;
                  
                  return (
                    <TableRow key={user.userId}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {user.name}
                          {isCurrentUser && (
                            <Badge variant="outline" className="text-xs">Sie</Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>{user.email}</TableCell>
                      <TableCell>
                        <Badge className={roleInfo[user.role as keyof typeof roleInfo]?.color}>
                          <RoleIcon className="w-3 h-3 mr-1" />
                          {roleInfo[user.role as keyof typeof roleInfo]?.name}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {new Date(user.createdAt).toLocaleDateString('de-DE')}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-2">
                          {user.role !== USER_ROLES.SUPER_ADMIN && (
                            <>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => {
                                  setEditingUser(user);
                                  setIsEditDialogOpen(true);
                                }}
                              >
                                <Edit className="w-4 h-4" />
                              </Button>
                              {!isCurrentUser && (
                                <AlertDialog>
                                  <AlertDialogTrigger asChild>
                                    <Button variant="ghost" size="sm">
                                      <Trash2 className="w-4 h-4" />
                                    </Button>
                                  </AlertDialogTrigger>
                                  <AlertDialogContent>
                                    <AlertDialogHeader>
                                      <AlertDialogTitle>Benutzer löschen?</AlertDialogTitle>
                                      <AlertDialogDescription>
                                        Sind Sie sicher, dass Sie {user.name} löschen möchten? 
                                        Diese Aktion kann nicht rückgängig gemacht werden.
                                      </AlertDialogDescription>
                                    </AlertDialogHeader>
                                    <AlertDialogFooter>
                                      <AlertDialogCancel>Abbrechen</AlertDialogCancel>
                                      <AlertDialogAction onClick={() => deleteUser(user.userId)}>
                                        Löschen
                                      </AlertDialogAction>
                                    </AlertDialogFooter>
                                  </AlertDialogContent>
                                </AlertDialog>
                              )}
                            </>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>

          {users.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              Noch keine Benutzer vorhanden.
            </div>
          )}
        </CardContent>
      </Card>

      {/* Edit User Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Benutzer bearbeiten</DialogTitle>
          </DialogHeader>
          {editingUser && (
            <div className="space-y-4">
              <div>
                <Label htmlFor="edit-name">Name</Label>
                <Input
                  id="edit-name"
                  value={editingUser.name}
                  onChange={(e) => setEditingUser({...editingUser, name: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="edit-email">E-Mail (nicht änderbar)</Label>
                <Input
                  id="edit-email"
                  value={editingUser.email}
                  disabled
                  className="bg-muted"
                />
              </div>
              <div>
                <Label htmlFor="edit-role">Rolle</Label>
                <Select 
                  value={editingUser.role} 
                  onValueChange={(value) => setEditingUser({...editingUser, role: value})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(roleInfo).filter(([key]) => key !== USER_ROLES.SUPER_ADMIN).map(([key, info]) => (
                      <SelectItem key={key} value={key}>
                        <div className="flex items-center gap-2">
                          <info.icon className="w-4 h-4" />
                          {info.name}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <p className="text-sm text-muted-foreground mt-1">
                  {roleInfo[editingUser.role as keyof typeof roleInfo]?.description}
                </p>
              </div>
              <div className="flex justify-end gap-2 pt-4">
                <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                  Abbrechen
                </Button>
                <Button onClick={updateUser} disabled={!editingUser.name.trim()}>
                  Speichern
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}