import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardHeader, CardTitle, CardContent } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from './ui/alert-dialog';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { Plus, Edit, Trash2, GripVertical, Users, BarChart3, Settings, LogOut, Eye, Crown, Shield, User as UserIcon } from 'lucide-react';
import { UserManagement } from './UserManagement';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface Question {
  id: number;
  text: string;
  category: string;
  order: number;
}

interface UserProfile {
  userId: string;
  email: string;
  name: string;
  role: string;
  createdAt: string;
}

interface AdminPanelProps {
  onLogout: () => void;
  onViewTest: () => void;
}

const USER_ROLES = {
  SUPER_ADMIN: 'super_admin',
  ADMIN: 'admin', 
  USER: 'user',
  VIEWER: 'viewer'
};

const roleInfo = {
  [USER_ROLES.SUPER_ADMIN]: { name: 'Super Admin', icon: Crown, color: 'text-amber-600' },
  [USER_ROLES.ADMIN]: { name: 'Administrator', icon: Shield, color: 'text-blue-600' },
  [USER_ROLES.USER]: { name: 'Benutzer', icon: UserIcon, color: 'text-green-600' },
  [USER_ROLES.VIEWER]: { name: 'Betrachter', icon: Eye, color: 'text-gray-600' }
};

const categoryInfo = {
  social: { name: 'Soziale Kommunikation', color: '#3b82f6' },
  masking: { name: 'Masking & Kompensation', color: '#8b5cf6' },
  sensory: { name: 'Routinen / Sensorik', color: '#f59e0b' },
  attention: { name: 'Aufmerksamkeitsregulation', color: '#10b981' },
  emotional: { name: 'Emotionale Steuerung', color: '#ef4444' }
};

export function AdminPanel({ onLogout, onViewTest }: AdminPanelProps) {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');
  const [editingQuestion, setEditingQuestion] = useState<Question | null>(null);
  const [newQuestion, setNewQuestion] = useState({ text: '', category: 'social' });
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [draggedItem, setDraggedItem] = useState<number | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);

  // Use shared Supabase client from utils

  const getAuthToken = () => localStorage.getItem('admin_token');

  const apiCall = async (endpoint: string, options: RequestInit = {}) => {
    const token = getAuthToken();
    const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-dd06a358${endpoint}`, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
        ...options.headers
      }
    });

    if (!response.ok) {
      if (response.status === 401) {
        onLogout();
        return null;
      }
      throw new Error(`API call failed: ${response.statusText}`);
    }

    return response.json();
  };

  const loadUserProfile = async () => {
    try {
      const data = await apiCall('/profile');
      if (data) {
        setUserProfile(data.profile);
      }
    } catch (error) {
      console.error('Error loading user profile:', error);
      onLogout(); // If we can't get profile, logout
    }
  };

  const loadQuestions = async () => {
    try {
      setLoading(true);
      const data = await apiCall('/admin/questions');
      if (data) {
        setQuestions(data.questions || []);
      }
    } catch (error) {
      console.error('Error loading questions:', error);
    } finally {
      setLoading(false);
    }
  };

  const initializeQuestions = async () => {
    try {
      const data = await apiCall('/admin/init-questions', { method: 'POST' });
      if (data) {
        await loadQuestions();
      }
    } catch (error) {
      console.error('Error initializing questions:', error);
    }
  };

  const addQuestion = async () => {
    try {
      const data = await apiCall('/admin/questions', {
        method: 'POST',
        body: JSON.stringify(newQuestion)
      });
      
      if (data) {
        await loadQuestions();
        setNewQuestion({ text: '', category: 'social' });
        setIsAddDialogOpen(false);
      }
    } catch (error) {
      console.error('Error adding question:', error);
    }
  };

  const updateQuestion = async () => {
    if (!editingQuestion) return;
    
    try {
      const data = await apiCall(`/admin/questions/${editingQuestion.id}`, {
        method: 'PUT',
        body: JSON.stringify({
          text: editingQuestion.text,
          category: editingQuestion.category
        })
      });
      
      if (data) {
        await loadQuestions();
        setEditingQuestion(null);
        setIsEditDialogOpen(false);
      }
    } catch (error) {
      console.error('Error updating question:', error);
    }
  };

  const deleteQuestion = async (id: number) => {
    try {
      const data = await apiCall(`/admin/questions/${id}`, {
        method: 'DELETE'
      });
      
      if (data) {
        await loadQuestions();
      }
    } catch (error) {
      console.error('Error deleting question:', error);
    }
  };

  const reorderQuestions = async (newOrder: number[]) => {
    try {
      const data = await apiCall('/admin/questions/reorder', {
        method: 'PUT',
        body: JSON.stringify({ questionIds: newOrder })
      });
      
      if (data) {
        await loadQuestions();
      }
    } catch (error) {
      console.error('Error reordering questions:', error);
    }
  };

  const handleDragStart = (e: React.DragEvent, questionId: number) => {
    setDraggedItem(questionId);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  };

  const handleDrop = (e: React.DragEvent, targetQuestionId: number) => {
    e.preventDefault();
    
    if (draggedItem === null || draggedItem === targetQuestionId) return;
    
    const newQuestions = [...questions];
    const draggedIndex = newQuestions.findIndex(q => q.id === draggedItem);
    const targetIndex = newQuestions.findIndex(q => q.id === targetQuestionId);
    
    const [draggedQuestion] = newQuestions.splice(draggedIndex, 1);
    newQuestions.splice(targetIndex, 0, draggedQuestion);
    
    const newOrder = newQuestions.map(q => q.id);
    reorderQuestions(newOrder);
    setDraggedItem(null);
  };

  useEffect(() => {
    const initialize = async () => {
      await loadUserProfile();
      await loadQuestions();
    };
    initialize();
  }, []);

  const groupedQuestions = questions.reduce((acc, question) => {
    if (!acc[question.category]) {
      acc[question.category] = [];
    }
    acc[question.category].push(question);
    return acc;
  }, {} as Record<string, Question[]>);

  const stats = {
    total: questions.length,
    byCategory: Object.entries(groupedQuestions).map(([category, qs]) => ({
      category,
      name: categoryInfo[category as keyof typeof categoryInfo]?.name || category,
      count: qs.length,
      color: categoryInfo[category as keyof typeof categoryInfo]?.color || '#666'
    }))
  };

  if (loading || !userProfile) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p>Lade Admin-Panel...</p>
        </div>
      </div>
    );
  }

  const userRole = userProfile.role;
  const canManageQuestions = userRole === USER_ROLES.SUPER_ADMIN || userRole === USER_ROLES.ADMIN;
  const canManageUsers = userRole === USER_ROLES.SUPER_ADMIN;
  const RoleIcon = roleInfo[userRole as keyof typeof roleInfo]?.icon || UserIcon;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <div className="bg-white border-b shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-4">
              <h1 className="text-2xl">Neurodiversitäts-Test Admin</h1>
              <div className="flex gap-2">
                <Button
                  variant={activeTab === 'overview' ? 'default' : 'ghost'}
                  onClick={() => setActiveTab('overview')}
                  className="flex items-center gap-2"
                >
                  <BarChart3 className="w-4 h-4" />
                  Übersicht
                </Button>
                {canManageQuestions && (
                  <Button
                    variant={activeTab === 'questions' ? 'default' : 'ghost'}
                    onClick={() => setActiveTab('questions')}
                    className="flex items-center gap-2"
                  >
                    <Settings className="w-4 h-4" />
                    Fragen verwalten
                  </Button>
                )}
                {canManageUsers && (
                  <Button
                    variant={activeTab === 'users' ? 'default' : 'ghost'}
                    onClick={() => setActiveTab('users')}
                    className="flex items-center gap-2"
                  >
                    <Users className="w-4 h-4" />
                    Benutzerverwaltung
                  </Button>
                )}
              </div>
            </div>
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-2 px-3 py-2 bg-slate-100 rounded-lg">
                <RoleIcon className={`w-4 h-4 ${roleInfo[userRole as keyof typeof roleInfo]?.color}`} />
                <span className="text-sm font-medium">{userProfile.name}</span>
                <Badge variant="outline" className="text-xs">
                  {roleInfo[userRole as keyof typeof roleInfo]?.name}
                </Badge>
              </div>
              <Button variant="outline" onClick={onViewTest} className="flex items-center gap-2">
                <Eye className="w-4 h-4" />
                Test ansehen
              </Button>
              <Button variant="outline" onClick={onLogout} className="flex items-center gap-2">
                <LogOut className="w-4 h-4" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6">
        {activeTab === 'overview' && (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Statistiken</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
                  <Card className="p-4">
                    <div className="text-2xl font-bold">{stats.total}</div>
                    <div className="text-sm text-muted-foreground">Gesamtfragen</div>
                  </Card>
                  <Card className="p-4">
                    <div className="text-2xl font-bold">{stats.byCategory.length}</div>
                    <div className="text-sm text-muted-foreground">Kategorien</div>
                  </Card>
                </div>
                
                <div className="space-y-3">
                  <h4>Fragen pro Kategorie:</h4>
                  {stats.byCategory.map(cat => (
                    <div key={cat.category} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div 
                          className="w-4 h-4 rounded"
                          style={{ backgroundColor: cat.color }}
                        />
                        <span>{cat.name}</span>
                      </div>
                      <Badge variant="secondary">{cat.count} Fragen</Badge>
                    </div>
                  ))}
                </div>

                {questions.length === 0 && (
                  <div className="text-center py-8">
                    <p className="text-muted-foreground mb-4">Noch keine Fragen vorhanden.</p>
                    <Button onClick={initializeQuestions}>
                      Standard-Fragen initialisieren
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )}

        {activeTab === 'users' && canManageUsers && (
          <UserManagement userProfile={userProfile} />
        )}

        {activeTab === 'questions' && canManageQuestions && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl">Fragen verwalten</h2>
              <div className="flex gap-2">
                {questions.length === 0 && (
                  <Button variant="outline" onClick={initializeQuestions}>
                    Standard-Fragen laden
                  </Button>
                )}
                <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
                  <DialogTrigger asChild>
                    <Button className="flex items-center gap-2">
                      <Plus className="w-4 h-4" />
                      Neue Frage
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Neue Frage hinzufügen</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="category">Kategorie</Label>
                        <Select value={newQuestion.category} onValueChange={(value) => setNewQuestion({...newQuestion, category: value})}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {Object.entries(categoryInfo).map(([key, info]) => (
                              <SelectItem key={key} value={key}>{info.name}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="text">Fragetext</Label>
                        <Textarea
                          value={newQuestion.text}
                          onChange={(e) => setNewQuestion({...newQuestion, text: e.target.value})}
                          placeholder="Geben Sie hier den Fragetext ein..."
                          rows={3}
                        />
                      </div>
                      <div className="flex justify-end gap-2">
                        <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                          Abbrechen
                        </Button>
                        <Button onClick={addQuestion} disabled={!newQuestion.text.trim()}>
                          Hinzufügen
                        </Button>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </div>

            {questions.length > 0 ? (
              <div className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  Ziehen Sie Fragen, um die Reihenfolge zu ändern. Insgesamt {questions.length} Fragen.
                </p>
                
                {Object.entries(groupedQuestions).map(([category, categoryQuestions]) => (
                  <Card key={category}>
                    <CardHeader className="pb-3">
                      <div className="flex items-center gap-3">
                        <div 
                          className="w-4 h-4 rounded"
                          style={{ backgroundColor: categoryInfo[category as keyof typeof categoryInfo]?.color }}
                        />
                        <CardTitle className="text-lg">
                          {categoryInfo[category as keyof typeof categoryInfo]?.name || category}
                        </CardTitle>
                        <Badge variant="secondary">{categoryQuestions.length} Fragen</Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        {categoryQuestions.map((question) => (
                          <div
                            key={question.id}
                            draggable
                            onDragStart={(e) => handleDragStart(e, question.id)}
                            onDragOver={handleDragOver}
                            onDrop={(e) => handleDrop(e, question.id)}
                            className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg hover:bg-slate-100 cursor-move"
                          >
                            <GripVertical className="w-4 h-4 text-muted-foreground" />
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <span className="text-sm font-medium">#{question.id}</span>
                                <Badge variant="outline" className="text-xs">
                                  Reihenfolge: {question.order}
                                </Badge>
                              </div>
                              <p className="text-sm">{question.text}</p>
                            </div>
                            <div className="flex items-center gap-2">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => {
                                  setEditingQuestion(question);
                                  setIsEditDialogOpen(true);
                                }}
                              >
                                <Edit className="w-4 h-4" />
                              </Button>
                              <AlertDialog>
                                <AlertDialogTrigger asChild>
                                  <Button variant="ghost" size="sm">
                                    <Trash2 className="w-4 h-4" />
                                  </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent>
                                  <AlertDialogHeader>
                                    <AlertDialogTitle>Frage löschen?</AlertDialogTitle>
                                    <AlertDialogDescription>
                                      Diese Aktion kann nicht rückgängig gemacht werden.
                                    </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel>Abbrechen</AlertDialogCancel>
                                    <AlertDialogAction onClick={() => deleteQuestion(question.id)}>
                                      Löschen
                                    </AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="text-center py-12">
                  <p className="text-muted-foreground mb-4">Noch keine Fragen vorhanden.</p>
                  <Button onClick={initializeQuestions}>
                    Standard-Fragen initialisieren
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        )}

        {/* Edit Dialog */}
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Frage bearbeiten</DialogTitle>
            </DialogHeader>
            {editingQuestion && (
              <div className="space-y-4">
                <div>
                  <Label htmlFor="edit-category">Kategorie</Label>
                  <Select 
                    value={editingQuestion.category} 
                    onValueChange={(value) => setEditingQuestion({...editingQuestion, category: value})}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(categoryInfo).map(([key, info]) => (
                        <SelectItem key={key} value={key}>{info.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="edit-text">Fragetext</Label>
                  <Textarea
                    value={editingQuestion.text}
                    onChange={(e) => setEditingQuestion({...editingQuestion, text: e.target.value})}
                    rows={3}
                  />
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                    Abbrechen
                  </Button>
                  <Button onClick={updateQuestion} disabled={!editingQuestion.text.trim()}>
                    Speichern
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}