import { useState, useEffect } from 'react';
import { Button } from '../components/ui/button';
import { Card, CardHeader, CardTitle, CardContent } from '../components/ui/card';
import { Progress } from '../components/ui/progress';
import { RadioGroup, RadioGroupItem } from '../components/ui/radio-group';
import { Label } from '../components/ui/label';
import { ArrowLeft, ArrowRight, CheckCircle, FileDown } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface TestSystemProps {
  testType: string;
  user: any;
  onComplete: () => void;
  onBack: () => void;
}

interface Question {
  id: number;
  text: string;
  category: string;
  order: number;
}

const testConfigs = {
  'raads-r': {
    name: 'RAADS-R',
    fullName: 'Ritvo Autism Asperger Diagnostic Scale - Revised',
    description: 'Umfassendes Autismus-Screening für Erwachsene',
    categories: {
      social: { name: 'Soziale Kommunikation', color: '#3b82f6' },
      masking: { name: 'Masking & Kompensation', color: '#8b5cf6' },
      sensory: { name: 'Routinen / Sensorik', color: '#f59e0b' },
      attention: { name: 'Aufmerksamkeitsregulation', color: '#10b981' },
      emotional: { name: 'Emotionale Steuerung', color: '#ef4444' }
    }
  },
  'cat-q': {
    name: 'CAT-Q',
    fullName: 'Camouflaging Autistic Traits Questionnaire',
    description: 'Erfassung von Masking-Verhalten',
    categories: {
      masking: { name: 'Masking-Verhalten', color: '#8b5cf6' },
      compensation: { name: 'Kompensation', color: '#f59e0b' },
      assimilation: { name: 'Assimilation', color: '#10b981' }
    }
  },
  'asrs': {
    name: 'ASRS',
    fullName: 'Adult ADHD Self-Report Scale',
    description: 'ADHS-Screening für Erwachsene',
    categories: {
      attention: { name: 'Aufmerksamkeit', color: '#3b82f6' },
      hyperactivity: { name: 'Hyperaktivität', color: '#ef4444' },
      impulsivity: { name: 'Impulsivität', color: '#f59e0b' }
    }
  }
};

const answerOptions = [
  { value: 1, label: 'Trifft nie zu' },
  { value: 2, label: 'Trifft selten zu' },
  { value: 3, label: 'Trifft oft zu' },
  { value: 4, label: 'Trifft immer zu' }
];

export function TestSystem({ testType, user, onComplete, onBack }: TestSystemProps) {
  const [currentScreen, setCurrentScreen] = useState('instructions'); // 'instructions', 'questions', 'results'
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [questions, setQuestions] = useState<Question[]>([]);
  const [loading, setLoading] = useState(true);

  const config = testConfigs[testType] || testConfigs['raads-r'];

  // Load questions from API
  const loadQuestions = async () => {
    try {
      setLoading(true);
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-dd06a358/questions`, {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        // Filter questions based on test type (for now use all questions)
        setQuestions(data.questions || []);
      } else {
        console.error('Failed to load questions');
      }
    } catch (error) {
      console.error('Error loading questions:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadQuestions();
  }, [testType]);

  const handleAnswer = (questionId: number, value: number) => {
    setAnswers(prev => ({ ...prev, [questionId]: value }));
  };

  const saveResults = async () => {
    try {
      await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-dd06a358/results`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`
        },
        body: JSON.stringify({
          testType,
          userId: user?.id,
          answers,
          timestamp: new Date().toISOString()
        })
      });
    } catch (error) {
      console.error('Error saving results:', error);
    }
  };

  const nextQuestion = async () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    } else {
      await saveResults();
      setCurrentScreen('results');
    }
  };

  const prevQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => prev - 1);
    }
  };

  const calculateResults = () => {
    const categoryScores: Record<string, { total: number; count: number }> = {};
    
    Object.entries(config.categories).forEach(([key]) => {
      categoryScores[key] = { total: 0, count: 0 };
    });

    questions.forEach(question => {
      const answer = answers[question.id];
      if (answer !== undefined) {
        const category = question.category;
        if (categoryScores[category]) {
          categoryScores[category].total += answer;
          categoryScores[category].count += 1;
        }
      }
    });

    return Object.entries(categoryScores).map(([category, data]) => ({
      category,
      name: config.categories[category]?.name || category,
      color: config.categories[category]?.color || '#3b82f6',
      score: data.count > 0 ? Math.round((data.total / (data.count * 4)) * 100) : 0,
      rawScore: data.total,
      maxScore: data.count * 4
    }));
  };

  const progress = questions.length > 0 ? ((currentQuestionIndex + 1) / questions.length) * 100 : 0;
  const currentQuestion = questions[currentQuestionIndex];
  const results = calculateResults();
  const isCurrentAnswered = currentQuestion ? answers[currentQuestion.id] !== undefined : false;
  const completedQuestions = Object.keys(answers).length;

  if (loading) {
    return (
      <div className="min-h-screen pt-24 pb-16 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto mb-4"></div>
          <p>Lade Test...</p>
        </div>
      </div>
    );
  }

  if (currentScreen === 'instructions') {
    return (
      <div className="min-h-screen pt-24 pb-16">
        <div className="max-w-4xl mx-auto px-4">
          <Button 
            variant="ghost" 
            onClick={onBack}
            className="mb-6 hover:bg-white/50"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Zurück zum Dashboard
          </Button>

          <Card className="bg-white/90 backdrop-blur-sm">
            <CardHeader className="text-center">
              <CardTitle className="text-3xl mb-2">{config.name}</CardTitle>
              <p className="text-lg text-gray-600">{config.fullName}</p>
              <p className="text-gray-600">{config.description}</p>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
                <h3 className="font-semibold text-blue-800 mb-3">Was Sie erwartet:</h3>
                <ul className="space-y-2 text-blue-700">
                  <li>• {questions.length} Fragen zu verschiedenen Lebensbereichen</li>
                  <li>• Bearbeitungszeit: ca. 10-20 Minuten</li>
                  <li>• 4-stufige Antwortskala (nie bis immer)</li>
                  <li>• Automatische Auswertung nach Abschluss</li>
                </ul>
              </div>

              <div className="bg-amber-50 border border-amber-200 rounded-lg p-6">
                <h3 className="font-semibold text-amber-800 mb-3">Wichtige Hinweise:</h3>
                <ul className="space-y-2 text-amber-700">
                  <li>• Antworten Sie ehrlich und spontan</li>
                  <li>• Es gibt keine "richtigen" oder "falschen" Antworten</li>
                  <li>• Denken Sie an Ihr Verhalten der letzten Jahre</li>
                  <li>• Sie können jederzeit zur vorherigen Frage zurück</li>
                </ul>
              </div>

              <div className="bg-green-50 border border-green-200 rounded-lg p-6">
                <h3 className="font-semibold text-green-800 mb-3">Kategorien:</h3>
                <div className="grid md:grid-cols-2 gap-3">
                  {Object.entries(config.categories).map(([key, category]) => (
                    <div key={key} className="flex items-center gap-2">
                      <div 
                        className="w-4 h-4 rounded"
                        style={{ backgroundColor: category.color }}
                      />
                      <span className="text-green-700 text-sm">{category.name}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="text-center pt-4">
                <Button 
                  onClick={() => setCurrentScreen('questions')} 
                  size="lg"
                  className="bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600 px-8"
                  disabled={questions.length === 0}
                >
                  Test beginnen
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (currentScreen === 'questions') {
    return (
      <div className="min-h-screen pt-24 pb-16">
        <div className="max-w-3xl mx-auto px-4">
          <Card className="bg-white/90 backdrop-blur-sm">
            <CardHeader>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">
                    Frage {currentQuestionIndex + 1} von {questions.length}
                  </span>
                  <span 
                    className="text-sm font-medium px-3 py-1 rounded-full text-white"
                    style={{ 
                      backgroundColor: config.categories[currentQuestion?.category]?.color || '#3b82f6' 
                    }}
                  >
                    {config.categories[currentQuestion?.category]?.name || 'Kategorie'}
                  </span>
                </div>
                <Progress value={progress} className="h-2" />
              </div>
            </CardHeader>
            <CardContent className="space-y-8">
              <div className="text-center">
                <h2 className="text-xl mb-6">{currentQuestion?.text}</h2>
              </div>
              
              <RadioGroup 
                value={answers[currentQuestion?.id]?.toString() || ''} 
                onValueChange={(value) => handleAnswer(currentQuestion.id, parseInt(value))}
                className="space-y-3"
              >
                {answerOptions.map((option) => (
                  <div 
                    key={option.value}
                    className="flex items-center space-x-2 p-4 rounded-lg border hover:bg-gray-50 transition-colors"
                  >
                    <RadioGroupItem value={option.value.toString()} id={`r${option.value}`} />
                    <Label htmlFor={`r${option.value}`} className="flex-1 cursor-pointer">
                      {option.label}
                    </Label>
                  </div>
                ))}
              </RadioGroup>
              
              <div className="flex justify-between pt-6">
                <Button 
                  variant="outline" 
                  onClick={prevQuestion}
                  disabled={currentQuestionIndex === 0}
                  className="flex items-center gap-2"
                >
                  <ArrowLeft className="w-4 h-4" />
                  Zurück
                </Button>
                <Button 
                  onClick={nextQuestion}
                  disabled={!isCurrentAnswered}
                  className="flex items-center gap-2 bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600"
                >
                  {currentQuestionIndex === questions.length - 1 ? 'Auswertung' : 'Weiter'}
                  <ArrowRight className="w-4 h-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (currentScreen === 'results') {
    const completionRate = Math.round((completedQuestions / questions.length) * 100);
    const overallScore = results.length > 0 
      ? Math.round(results.reduce((acc, result) => acc + result.score, 0) / results.length)
      : 0;

    return (
      <div className="min-h-screen pt-24 pb-16">
        <div className="max-w-6xl mx-auto px-4">
          <Card className="bg-white/90 backdrop-blur-sm">
            <CardHeader className="text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 rounded-full mb-4">
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
              <CardTitle className="text-3xl mb-2">{config.name} - Ergebnisse</CardTitle>
              <p className="text-gray-600">
                Test abgeschlossen • {completedQuestions} von {questions.length} Fragen beantwortet ({completionRate}%)
              </p>
            </CardHeader>
            <CardContent className="space-y-8">
              <div className="grid md:grid-cols-3 gap-6">
                <Card className="bg-gradient-to-br from-blue-50 to-purple-50 border-blue-200">
                  <CardContent className="p-6 text-center">
                    <h3 className="font-semibold text-gray-700 mb-2">Gesamtscore</h3>
                    <p className="text-3xl font-bold text-blue-600">{overallScore}%</p>
                  </CardContent>
                </Card>
                <Card className="bg-gradient-to-br from-green-50 to-teal-50 border-green-200">
                  <CardContent className="p-6 text-center">
                    <h3 className="font-semibold text-gray-700 mb-2">Vollständigkeit</h3>
                    <p className="text-3xl font-bold text-green-600">{completionRate}%</p>
                  </CardContent>
                </Card>
                <Card className="bg-gradient-to-br from-orange-50 to-red-50 border-orange-200">
                  <CardContent className="p-6 text-center">
                    <h3 className="font-semibold text-gray-700 mb-2">Kategorien</h3>
                    <p className="text-3xl font-bold text-orange-600">{results.length}</p>
                  </CardContent>
                </Card>
              </div>

              <div className="grid lg:grid-cols-2 gap-8">
                <div>
                  <h3 className="text-xl font-semibold mb-4">Kategorien-Übersicht</h3>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={results}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis 
                        dataKey="name" 
                        angle={-45} 
                        textAnchor="end" 
                        height={80}
                        fontSize={12}
                      />
                      <YAxis />
                      <Tooltip 
                        formatter={(value) => [`${value}%`, 'Score']}
                        labelFormatter={(label) => `Kategorie: ${label}`}
                      />
                      <Bar dataKey="score" fill="#3b82f6" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>

                <div className="space-y-4">
                  <h3 className="text-xl font-semibold">Detaillierte Auswertung</h3>
                  {results.map((result, index) => (
                    <Card key={index} className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium" style={{ color: result.color }}>
                          {result.name}
                        </h4>
                        <span className="font-bold text-lg">{result.score}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2 mb-2">
                        <div 
                          className="h-2 rounded-full" 
                          style={{ 
                            backgroundColor: result.color, 
                            width: `${result.score}%` 
                          }}
                        />
                      </div>
                      <p className="text-sm text-gray-600">
                        {result.rawScore} von {result.maxScore} Punkten
                      </p>
                    </Card>
                  ))}
                </div>
              </div>

              <div className="bg-amber-50 border border-amber-200 rounded-lg p-6">
                <h3 className="font-semibold text-amber-800 mb-3">Interpretation</h3>
                <p className="text-amber-700 mb-3">
                  Diese Ergebnisse geben Ihnen einen Einblick in verschiedene Aspekte Ihres Erlebens und Verhaltens. 
                  Höhere Werte können auf neurodivergente Eigenschaften hindeuten.
                </p>
                <p className="text-amber-700 text-sm">
                  <strong>Wichtig:</strong> Dies ist ein Screening-Tool und ersetzt keine professionelle Diagnose. 
                  Bei Fragen wenden Sie sich an qualifizierte Fachkräfte.
                </p>
              </div>

              <div className="flex justify-center gap-4">
                <Button 
                  variant="outline"
                  onClick={onComplete}
                  className="flex items-center gap-2"
                >
                  Zurück zum Dashboard
                </Button>
                <Button 
                  className="flex items-center gap-2"
                  onClick={() => {
                    const dataStr = JSON.stringify({ testType, config, results, answers }, null, 2);
                    const dataBlob = new Blob([dataStr], {type: 'application/json'});
                    const url = URL.createObjectURL(dataBlob);
                    const link = document.createElement('a');
                    link.href = url;
                    link.download = `${config.name}-ergebnis-${new Date().toISOString().split('T')[0]}.json`;
                    link.click();
                  }}
                >
                  <FileDown className="w-4 h-4" />
                  Ergebnisse speichern
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return null;
}